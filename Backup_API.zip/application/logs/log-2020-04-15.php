<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-15 01:35:42 --> [{"namestore":"Bani Dipatiukur","idauthstaff":"59","idstore":"1","level":"0","status":"0","name":"lois1","phone":"98","username":"lois1","password":"53e484660e34a280db6b25a8eec2bc2d","keyCodeStaff":"172cbd2f756a413accc89870b18574fb","secret":"41bac1443457e8d22640a26b4a23b0442e803b3e3a6b133c6ab5c6194b1ef2d1","statusdel":"0"}]
ERROR - 2020-04-15 01:35:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:35:42 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:35:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:35:42 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:35:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 661
ERROR - 2020-04-15 01:35:42 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 661
ERROR - 2020-04-15 01:35:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/system/core/Exceptions.php:271) /var/www/html/system/core/Common.php 570
ERROR - 2020-04-15 01:35:44 --> [{"namestore":"Bani Dipatiukur","idauthstaff":"59","idstore":"1","level":"0","status":"0","name":"lois1","phone":"98","username":"lois1","password":"53e484660e34a280db6b25a8eec2bc2d","keyCodeStaff":"172cbd2f756a413accc89870b18574fb","secret":"41bac1443457e8d22640a26b4a23b0442e803b3e3a6b133c6ab5c6194b1ef2d1","statusdel":"0"}]
ERROR - 2020-04-15 01:35:44 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:35:44 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:35:44 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:35:44 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:35:44 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 661
ERROR - 2020-04-15 01:35:44 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 661
ERROR - 2020-04-15 01:35:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/system/core/Exceptions.php:271) /var/www/html/system/core/Common.php 570
ERROR - 2020-04-15 01:36:06 --> [{"namestore":"Bani Dipatiukur","idauthstaff":"59","idstore":"1","level":"0","status":"0","name":"lois1","phone":"98","username":"lois1","password":"53e484660e34a280db6b25a8eec2bc2d","keyCodeStaff":"172cbd2f756a413accc89870b18574fb","secret":"41bac1443457e8d22640a26b4a23b0442e803b3e3a6b133c6ab5c6194b1ef2d1","statusdel":"0"}]
ERROR - 2020-04-15 01:36:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:36:06 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:36:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:36:06 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:36:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 661
ERROR - 2020-04-15 01:36:06 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 661
ERROR - 2020-04-15 01:36:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/system/core/Exceptions.php:271) /var/www/html/system/core/Common.php 570
ERROR - 2020-04-15 01:36:50 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-04-15 01:37:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 655
ERROR - 2020-04-15 01:37:12 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 655
ERROR - 2020-04-15 01:37:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:37:12 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 657
ERROR - 2020-04-15 01:37:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:37:12 --> Severity: Notice --> Trying to get property 'idproduct' of non-object /var/www/html/application/models/Admin_model.php 659
ERROR - 2020-04-15 01:37:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/system/core/Exceptions.php:271) /var/www/html/system/core/Common.php 570
ERROR - 2020-04-15 01:39:03 --> Severity: Notice --> Undefined property: Dev::$db /var/www/html/application/controllers/Dev.php 89
ERROR - 2020-04-15 01:39:03 --> Severity: error --> Exception: Call to a member function select() on null /var/www/html/application/controllers/Dev.php 90
ERROR - 2020-04-15 01:40:30 --> The upload path does not appear to be valid.
ERROR - 2020-04-15 01:41:51 --> The upload path does not appear to be valid.
ERROR - 2020-04-15 01:45:57 --> 404 Page Not Found: Dev/get_users
ERROR - 2020-04-15 01:46:01 --> Query error: Table 'main.productDitails' doesn't exist - Invalid query: SELECT *
FROM `productDitails`
ERROR - 2020-04-15 01:47:30 --> Query error: Unknown column 'sku' in 'where clause' - Invalid query: SELECT *
FROM `product`
WHERE `sku` = 'SDF445566'
ERROR - 2020-04-15 01:49:48 --> Severity: error --> Exception: Call to undefined method Sensus_model::empty_response() /var/www/html/application/models/Sensus_model.php 322
ERROR - 2020-04-15 01:50:07 --> Query error: Table 'main.productDitails' doesn't exist - Invalid query: SELECT *
FROM `productDitails`
ERROR - 2020-04-15 02:00:19 --> Query error: Unknown column 'idproduct' in 'where clause' - Invalid query: SELECT *
FROM `product_sku`
WHERE `idproduct` = '323'
ERROR - 2020-04-15 02:00:39 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::limit() /var/www/html/application/controllers/Dev.php 107
